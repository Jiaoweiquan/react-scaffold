import * as URL from './url'

export { URL }

export const LANGUAGES = ['zh-CN', 'en-US']
