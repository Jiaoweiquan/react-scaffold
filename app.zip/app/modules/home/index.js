import * as T from './actionTypes'
import * as actions from './actions'
import * as reducers from './reducers'

export default {
  T,
  actions,
  reducers
}
