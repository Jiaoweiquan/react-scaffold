export const homeSelector = state => state.home
