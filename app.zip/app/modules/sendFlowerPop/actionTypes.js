export const OPEN_POP = 'SF/OPEN_POP'
export const CLOSE_POP = 'SF/CLOSE_POP'
export const SEND_FLOWER = 'SF/SEND_FLOWER'
