import * as T from './actionTypes'
import * as actions from './actions'
import component from './components'
import * as reducers from './reducers'

export default {
  T,
  actions,
  component,
  reducers
}
