import { createAction } from 'redux-actions'
import * as T from './actionTypes'

export const changeLanguage = createAction(T.CHANGE_LANGUAGE)
