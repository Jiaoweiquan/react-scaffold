export const languageSelector = state => state.language
