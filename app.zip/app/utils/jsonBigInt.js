const JSONbigString = require('json-bigint')({storeAsString: true})
export default JSONbigString
