import 'core-js/es6/promise'
import 'core-js/fn/symbol'

// String
import 'core-js/fn/string/includes'
import 'core-js/fn/string/starts-with'
import 'core-js/fn/string/ends-with'

// Array
import 'core-js/fn/array/includes'
import 'core-js/fn/array/find'
import 'core-js/fn/array/is-array'
