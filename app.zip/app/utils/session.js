import Storage from 'nd-storage'

// sessionStorage
export default new Storage(null, -1)
