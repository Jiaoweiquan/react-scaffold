import Storage from 'nd-storage'

// 默认一周有效期
export default new Storage(null, 7 * 24 * 3600)
